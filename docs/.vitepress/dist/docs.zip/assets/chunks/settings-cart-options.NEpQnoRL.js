const s="/assets/settings-product-exclusion.Bw9qbPnq.png",t="/assets/settings-cart-options.BN2Jhaq6.png";export{s as _,t as a};
